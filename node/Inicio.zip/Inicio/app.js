var calculadora = require("./calculadora");



console.log(calculadora.mult(10,20));
console.log(calculadora.soma(20,40));
calculadora.nome = "Calculadora do Victor!"
console.log(calculadora.nome);










/*var mostrarSite = true;
const site = "www.guiadoprogramador.com";

console.log("Hello World!");
console.log("Meu nome é Victor!");
console.log("E eu estou aprendendo Node.js com o Guia do programador");

if(mostrarSite){ // Se mostrar site
    console.log(site); // Printe o site
}*/